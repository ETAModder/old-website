![King Creeper face](https://cdn.modrinth.com/data/cached_images/8ae7c9e9ffb9ca6f667716a95dab911a0f6e9770.png)
# ETAGamer Website
## a really cool site i made for no reason

_Why did I make this?_
1. Because it's fun
2. Because I wanted to learn HTML, CSS, & JS.
3. Cause why not?

_Is this README file just so things don't yell at me?_
  ~~Yes!~~

_Did I use Modrinth to make this file because I'm lazy????_







  ~~yeah~~

**By ETAGamer / ETAModder**
